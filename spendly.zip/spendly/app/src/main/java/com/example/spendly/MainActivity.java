package com.example.spendly;

public class MainActivity {
}
