package com.example.spendly;

public class BudgetView {
}
