package Utils;

public class Constants {
    public static final String SHARED_PREFS_NAME = "budget_buddy_prefs";
    public static final String KEY_USER_NAME = "user_name";
    public static final String KEY_USER_EMAIL = "user_email";
    public static final String KEY_USER_PHOTO_URL = "user_email";

}
